# Al-Bayan (الباحث الإسلامي الذكي) - Replit Guide

## Overview

Al-Bayan is an AI-powered Islamic research platform that connects Quran, Hadith, and Tafsir (commentary) with intelligent search and chat capabilities. The app is an Arabic-first (RTL) web application that allows users to browse Quranic verses with tafsir, explore hadith collections, perform unified search across Islamic texts, and interact with an AI assistant that provides answers grounded in Islamic sources.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Full-Stack Structure
The project follows a monorepo pattern with three main directories:
- `client/` — React frontend (SPA)
- `server/` — Express.js backend (API server)
- `shared/` — Shared TypeScript types and database schema (used by both client and server)

### Frontend Architecture
- **Framework**: React with TypeScript (no SSR — `rsc: false`)
- **Routing**: Wouter (lightweight client-side router)
- **State/Data Fetching**: TanStack React Query for server state management
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives
- **Styling**: Tailwind CSS v4 with CSS variables for theming, custom Islamic green & gold color theme
- **Animations**: Framer Motion
- **Fonts**: Amiri (Quranic text), Cairo (Arabic UI), Inter (Latin text)
- **Build Tool**: Vite
- **Language Direction**: RTL (right-to-left) Arabic-first interface

Key pages:
- `/` — Home with search bar and stats
- `/search` — Unified search across Quran and Hadith with highlighting
- `/quran` — Surah browser with verse display and expandable tafsir
- `/hadith` — Hadith collection browser by source with grade badges
- `/chat` — AI-powered Islamic Q&A assistant with RAG

Path aliases are configured: `@/` maps to `client/src/`, `@shared/` maps to `shared/`.

### Backend Architecture
- **Framework**: Express.js v5 on Node.js
- **Language**: TypeScript, executed via `tsx` in development
- **API Pattern**: RESTful JSON APIs under `/api/` prefix
- **Build**: esbuild bundles the server for production as `dist/index.cjs`
- **Dev Server**: Vite dev server is integrated as middleware during development; static files served in production

Key API endpoints:
- `GET /api/search?q=&type=` — Unified search across verses and hadiths (supports `all`, `quran`, `hadith`)
- `GET /api/surahs` — List all surahs with ayah counts
- `GET /api/surah/:number` — Get verses for a specific surah with tafsir
- `GET /api/hadith/sources` — List hadith sources with counts
- `GET /api/hadith/:source` — Get hadiths by source (supports pagination via `limit` & `offset`)
- `POST /api/chat` — AI chat endpoint with RAG context retrieval
- `GET /api/stats` — Database statistics (verse count, hadith count, surah count)

### AI Integration
- **Provider**: Groq SDK (uses `GROQ_API_KEY` environment variable)
- **Model**: llama-3.3-70b-versatile
- **Pattern**: RAG (Retrieval-Augmented Generation) — the server retrieves relevant Quran/Hadith context from the database using text search and includes it in prompts to ground AI responses in authentic Islamic sources
- **Safety**: System prompt enforces source-based answers only, prevents hallucination of Islamic texts

### Database
- **Database**: PostgreSQL (required, uses `DATABASE_URL` environment variable)
- **ORM**: Drizzle ORM with `drizzle-zod` for schema validation
- **Schema** (in `shared/schema.ts`):
  - `verses` — Quran verses with surah info, Arabic text (with and without diacritics), juz number
  - `tafsirs` — Tafsir/commentary linked to verses by verse ID, with source attribution
  - `hadiths` — Hadith texts with source, chapter, grade, narrator
- **Migrations**: Drizzle Kit with `drizzle-kit push` for schema sync
- **Seeding**: `server/seed.ts` populates initial data on startup (50 verses from 10 surahs, 20 hadiths from 5 sources, tafsir entries)

### Storage Layer
- `server/storage.ts` implements `IStorage` interface with `DatabaseStorage` class
- Provides search (using `ILIKE` for Arabic text matching), CRUD operations, and RAG context retrieval
- Uses `pg` Pool for connection management
- Batch insert support for seeding (500 records per batch)

## External Dependencies

### Required Environment Variables
- `DATABASE_URL` — PostgreSQL connection string (required, will fail to start without it)
- `GROQ_API_KEY` — API key for Groq AI service (required for chat functionality)

### Third-Party Services
- **Groq AI** — LLM provider for the Islamic Q&A chat assistant (llama-3.3-70b-versatile model)
- **PostgreSQL** — Primary data store for all Quran, Hadith, and Tafsir data
- **Google Fonts** — Amiri, Cairo, and Inter font families loaded from Google CDN

### Key NPM Dependencies
- `express` v5 — HTTP server
- `drizzle-orm` + `drizzle-kit` — Database ORM and migration tooling
- `pg` — PostgreSQL client
- `groq-sdk` — Groq AI API client
- `@tanstack/react-query` — Client-side data fetching
- `wouter` — Client-side routing
- `framer-motion` — Animations
- `zod` + `drizzle-zod` — Runtime validation
- Radix UI primitives — Accessible UI components

### Replit-Specific Plugins
- `@replit/vite-plugin-runtime-error-modal` — Error overlay in development
- `@replit/vite-plugin-cartographer` — Dev tooling (dev only)
- `@replit/vite-plugin-dev-banner` — Dev banner (dev only)
- Custom `vite-plugin-meta-images` — Updates OpenGraph meta tags with Replit deployment URL

## Recent Changes
- 2026-02-06: Full-stack implementation completed
  - Database schema created (verses, tafsirs, hadiths tables)
  - Seed data: 50 Quran verses from 10 surahs, 20 hadiths from 5 sources, tafsir entries
  - Backend API routes for search, browse, chat with RAG
  - Frontend connected to real APIs (no more mock data)
  - Groq AI integration with llama-3.3-70b model for chat
  - Islamic green & gold design theme with RTL support
