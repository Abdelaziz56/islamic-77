import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { seedFullDatabase } from "./seed-full";
import Groq from "groq-sdk";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  await seedFullDatabase();

  // --- Search API ---
  app.get("/api/search", async (req, res) => {
    try {
      const query = (req.query.q as string) || "";
      const type = (req.query.type as string) || "all";

      if (!query) {
        return res.json({ verses: [], hadiths: [] });
      }

      let searchVerses: any[] = [];
      let searchHadiths: any[] = [];

      if (type === "all" || type === "quran") {
        searchVerses = await storage.searchVerses(query, 20);
        for (const verse of searchVerses) {
          const tafsirList = await storage.getTafsirForVerse(verse.id);
          (verse as any).tafsir = tafsirList[0]?.textAr || "";
        }
      }

      if (type === "all" || type === "hadith") {
        searchHadiths = await storage.searchHadiths(query, 20);
      }

      res.json({ verses: searchVerses, hadiths: searchHadiths });
    } catch (error: any) {
      console.error("Search error:", error);
      res.status(500).json({ message: "حدث خطأ أثناء البحث" });
    }
  });

  // --- Quran APIs ---
  app.get("/api/surahs", async (_req, res) => {
    try {
      const surahs = await storage.getAllSurahs();
      res.json(surahs);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/surah/:number", async (req, res) => {
    try {
      const surahNumber = parseInt(req.params.number);
      const versesData = await storage.getVersesBySurah(surahNumber);
      
      const versesWithTafsir = await Promise.all(
        versesData.map(async (v) => {
          const tafsirList = await storage.getTafsirForVerse(v.id);
          return { ...v, tafsir: tafsirList[0]?.textAr || "" };
        })
      );

      res.json(versesWithTafsir);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // --- Hadith APIs ---
  app.get("/api/hadith/sources", async (_req, res) => {
    try {
      const sources = await storage.getHadithSources();
      res.json(sources);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/hadith/:source", async (req, res) => {
    try {
      const source = decodeURIComponent(req.params.source);
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const hadithsData = await storage.getHadithsBySource(source, limit, offset);
      res.json(hadithsData);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // --- Stats ---
  app.get("/api/stats", async (_req, res) => {
    try {
      const verseCount = await storage.getVerseCount();
      const hadithCount = await storage.getHadithCount();
      const surahCount = (await storage.getAllSurahs()).length;
      res.json({ verseCount, hadithCount, surahCount });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // --- AI Chat with RAG ---
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ message: "الرسائل مطلوبة" });
      }

      const lastUserMessage = messages.filter((m: any) => m.role === "user").pop();
      if (!lastUserMessage) {
        return res.status(400).json({ message: "لا توجد رسالة من المستخدم" });
      }

      const context = await storage.getContextForRAG(lastUserMessage.content, 5);

      const systemPrompt = `أنت مساعد إسلامي متخصص يعتمد حصرياً على المصادر الشرعية الموثوقة (القرآن الكريم، التفسير، الحديث النبوي الشريف). 

القواعد التي يجب عليك اتباعها:
1. أجب فقط بناءً على المعلومات المقدمة لك من النصوص الشرعية أدناه.
2. إذا لم تجد إجابة في النصوص المقدمة، قل: "لم أجد في قاعدة البيانات نصاً محدداً يجيب عن هذا السؤال. أنصح بالرجوع إلى أهل العلم."
3. لا تخترع أو تختلق أي حديث أو آية أو تفسير.
4. عند الاستشهاد، اذكر المصدر (اسم السورة ورقم الآية، أو اسم كتاب الحديث ورقمه).
5. استخدم لغة عربية فصحى واضحة ومبسطة.
6. كن مختصراً ومفيداً في إجاباتك.

${context ? `النصوص الشرعية ذات الصلة بالسؤال:\n${context}` : "لم يتم العثور على نصوص ذات صلة مباشرة في قاعدة البيانات."}`;

      const chatMessages = [
        { role: "system" as const, content: systemPrompt },
        ...messages.slice(-6).map((m: any) => ({
          role: m.role as "user" | "assistant",
          content: m.content,
        })),
      ];

      const completion = await groq.chat.completions.create({
        model: "llama-3.3-70b-versatile",
        messages: chatMessages,
        temperature: 0.3,
        max_tokens: 1024,
      });

      const reply = completion.choices[0]?.message?.content || "عذراً، لم أتمكن من إنشاء رد. يرجى المحاولة مرة أخرى.";

      res.json({ 
        role: "assistant", 
        content: reply,
        sources: context ? "تم الاستعانة بنصوص من القرآن والحديث" : "إجابة عامة"
      });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ message: "حدث خطأ أثناء معالجة السؤال. تأكد من صحة مفتاح API." });
    }
  });

  return httpServer;
}
