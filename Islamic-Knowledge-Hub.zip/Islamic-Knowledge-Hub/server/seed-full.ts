import { db } from "./storage";
import { verses, tafsirs, hadiths } from "@shared/schema";
import { sql } from "drizzle-orm";
import type { InsertVerse, InsertTafsir, InsertHadith } from "@shared/schema";

const QURAN_API = "https://api.alquran.cloud/v1";
const HADITH_CDN = "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1";

async function fetchJSON(url: string, retries = 3): Promise<any> {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
      return await res.json();
    } catch (err) {
      console.log(`Retry ${i + 1}/${retries} for ${url}: ${err}`);
      if (i === retries - 1) throw err;
      await new Promise(r => setTimeout(r, 2000 * (i + 1)));
    }
  }
}

async function seedQuran() {
  console.log("📖 Fetching complete Quran (Uthmani script)...");
  const uthmaniData = await fetchJSON(`${QURAN_API}/quran/quran-uthmani`);
  
  console.log("📖 Fetching simple Arabic text...");
  const simpleData = await fetchJSON(`${QURAN_API}/quran/quran-simple`);

  const uthmaniSurahs = uthmaniData.data.surahs;
  const simpleSurahs = simpleData.data.surahs;

  const allVerses: InsertVerse[] = [];

  for (let i = 0; i < uthmaniSurahs.length; i++) {
    const surah = uthmaniSurahs[i];
    const simpleSurah = simpleSurahs[i];
    
    for (let j = 0; j < surah.ayahs.length; j++) {
      const ayah = surah.ayahs[j];
      const simpleAyah = simpleSurah.ayahs[j];
      
      allVerses.push({
        surahNumber: surah.number,
        surahNameAr: surah.name.replace(/^سُورَةُ\s*/, "").replace(/^سُورَة\s*/, ""),
        surahNameEn: surah.englishName,
        ayahNumber: ayah.numberInSurah,
        textAr: ayah.text,
        textSimple: simpleAyah.text,
        juzNumber: ayah.juz,
      });
    }
  }

  console.log(`📖 Inserting ${allVerses.length} verses in batches...`);
  const batchSize = 500;
  for (let i = 0; i < allVerses.length; i += batchSize) {
    const batch = allVerses.slice(i, i + batchSize);
    await db.insert(verses).values(batch);
    console.log(`   Inserted verses ${i + 1}-${Math.min(i + batchSize, allVerses.length)}`);
  }
  console.log(`✅ Quran complete: ${allVerses.length} verses inserted`);
}

async function seedTafsir() {
  console.log("📚 Fetching Tafsir Ibn Kathir...");
  
  const allInsertedVerses = await db.select({
    id: verses.id,
    surahNumber: verses.surahNumber,
    ayahNumber: verses.ayahNumber,
  }).from(verses);

  const verseMap = new Map<string, number>();
  for (const v of allInsertedVerses) {
    verseMap.set(`${v.surahNumber}:${v.ayahNumber}`, v.id);
  }

  const allTafsirs: InsertTafsir[] = [];

  for (let surahNum = 1; surahNum <= 114; surahNum++) {
    try {
      console.log(`   Fetching tafsir for surah ${surahNum}/114...`);
      const data = await fetchJSON(`${QURAN_API}/surah/${surahNum}/ar.ibnkathir`);
      
      if (data.data && data.data.ayahs) {
        for (const ayah of data.data.ayahs) {
          const verseId = verseMap.get(`${surahNum}:${ayah.numberInSurah}`);
          if (verseId && ayah.text && ayah.text.trim().length > 0) {
            allTafsirs.push({
              verseId,
              surahNumber: surahNum,
              ayahNumber: ayah.numberInSurah,
              source: "ابن كثير",
              textAr: ayah.text,
            });
          }
        }
      }
    } catch (err) {
      console.log(`   ⚠ Could not fetch tafsir for surah ${surahNum}: ${err}`);
    }
    
    if (surahNum % 10 === 0) {
      await new Promise(r => setTimeout(r, 500));
    }
  }

  if (allTafsirs.length > 0) {
    console.log(`📚 Inserting ${allTafsirs.length} tafsir entries...`);
    const batchSize = 500;
    for (let i = 0; i < allTafsirs.length; i += batchSize) {
      const batch = allTafsirs.slice(i, i + batchSize);
      await db.insert(tafsirs).values(batch);
      console.log(`   Inserted tafsirs ${i + 1}-${Math.min(i + batchSize, allTafsirs.length)}`);
    }
    console.log(`✅ Tafsir complete: ${allTafsirs.length} entries inserted`);
  } else {
    console.log("⚠ No tafsir data was fetched. Will try alternative source...");
    await seedTafsirAlternative(verseMap);
  }
}

async function seedTafsirAlternative(verseMap: Map<string, number>) {
  console.log("📚 Trying alternative tafsir source...");
  
  try {
    const data = await fetchJSON(`${QURAN_API}/quran/ar.muyassar`);
    
    if (data.data && data.data.surahs) {
      const allTafsirs: InsertTafsir[] = [];
      
      for (const surah of data.data.surahs) {
        for (const ayah of surah.ayahs) {
          const verseId = verseMap.get(`${surah.number}:${ayah.numberInSurah}`);
          if (verseId && ayah.text && ayah.text.trim().length > 0) {
            allTafsirs.push({
              verseId,
              surahNumber: surah.number,
              ayahNumber: ayah.numberInSurah,
              source: "التفسير الميسر",
              textAr: ayah.text,
            });
          }
        }
      }

      if (allTafsirs.length > 0) {
        console.log(`📚 Inserting ${allTafsirs.length} tafsir entries (الميسر)...`);
        const batchSize = 500;
        for (let i = 0; i < allTafsirs.length; i += batchSize) {
          const batch = allTafsirs.slice(i, i + batchSize);
          await db.insert(tafsirs).values(batch);
        }
        console.log(`✅ Tafsir (الميسر) complete: ${allTafsirs.length} entries inserted`);
      }
    }
  } catch (err) {
    console.log(`⚠ Alternative tafsir also failed: ${err}`);
  }
}

const HADITH_EDITIONS = [
  { edition: "ara-bukhari", source: "صحيح البخاري", sourceEn: "Sahih al-Bukhari" },
  { edition: "ara-muslim", source: "صحيح مسلم", sourceEn: "Sahih Muslim" },
  { edition: "ara-tirmidhi", source: "سنن الترمذي", sourceEn: "Jami at-Tirmidhi" },
  { edition: "ara-abudawud", source: "سنن أبي داود", sourceEn: "Sunan Abu Dawud" },
  { edition: "ara-nasai", source: "سنن النسائي", sourceEn: "Sunan an-Nasai" },
  { edition: "ara-ibnmajah", source: "سنن ابن ماجه", sourceEn: "Sunan Ibn Majah" },
];

async function seedHadiths() {
  console.log("📜 Fetching hadith collections...");

  for (const collection of HADITH_EDITIONS) {
    try {
      console.log(`   Fetching ${collection.sourceEn} (${collection.source})...`);
      const data = await fetchJSON(`${HADITH_CDN}/editions/${collection.edition}.json`);

      if (!data || !data.hadiths || !Array.isArray(data.hadiths)) {
        console.log(`   ⚠ No data for ${collection.source}`);
        continue;
      }

      const hadithsToInsert: InsertHadith[] = [];
      
      for (const h of data.hadiths) {
        if (!h.text || h.text.trim().length === 0) continue;
        
        let hadithNum = hadithsToInsert.length + 1;
        if (h.hadithnumber != null) {
          const parsed = parseInt(String(h.hadithnumber), 10);
          if (!isNaN(parsed)) hadithNum = parsed;
        }
        
        hadithsToInsert.push({
          source: collection.source,
          chapter: h.chapterTitle || h.bookName || "",
          numberInBook: hadithNum,
          textAr: h.text,
          grade: h.grades?.[0]?.grade || "",
          narrator: "",
        });
      }

      if (hadithsToInsert.length > 0) {
        console.log(`   Inserting ${hadithsToInsert.length} hadiths for ${collection.source}...`);
        const batchSize = 500;
        for (let i = 0; i < hadithsToInsert.length; i += batchSize) {
          const batch = hadithsToInsert.slice(i, i + batchSize);
          await db.insert(hadiths).values(batch);
        }
        console.log(`   ✅ ${collection.source}: ${hadithsToInsert.length} hadiths inserted`);
      }
    } catch (err) {
      console.log(`   ⚠ Error fetching ${collection.source}: ${err}`);
    }

    await new Promise(r => setTimeout(r, 1000));
  }

  console.log("✅ Hadith seeding complete");
}

export async function seedFullDatabase() {
  console.log("===========================================");
  console.log("   بدء تحميل قاعدة البيانات الكاملة");
  console.log("   Full Database Seeding Started");
  console.log("===========================================\n");

  const existingVerses = await db.select({ count: sql<number>`count(*)::int` }).from(verses);
  const existingHadiths = await db.select({ count: sql<number>`count(*)::int` }).from(hadiths);
  
  if (existingVerses[0].count > 100 && existingHadiths[0].count > 20000) {
    console.log(`Database already seeded (${existingVerses[0].count} verses, ${existingHadiths[0].count} hadiths). Skipping.`);
    return;
  }

  if (existingVerses[0].count <= 100) {
    console.log("Clearing existing data...");
    await db.delete(tafsirs);
    await db.delete(hadiths);
    await db.delete(verses);
    await seedQuran();
    await seedTafsir();
  } else {
    console.log(`Quran already loaded (${existingVerses[0].count} verses). Skipping Quran/Tafsir.`);
  }

  if (existingHadiths[0].count < 20000) {
    if (existingHadiths[0].count > 0) {
      console.log(`Clearing incomplete hadith data (${existingHadiths[0].count} hadiths)...`);
      await db.delete(hadiths);
    }
    await seedHadiths();
  }

  const finalVerseCount = await db.select({ count: sql<number>`count(*)::int` }).from(verses);
  const finalHadithCount = await db.select({ count: sql<number>`count(*)::int` }).from(hadiths);
  const finalTafsirCount = await db.select({ count: sql<number>`count(*)::int` }).from(tafsirs);

  console.log("\n===========================================");
  console.log("   Database Seeding Summary:");
  console.log(`   📖 Quran Verses: ${finalVerseCount[0].count}`);
  console.log(`   📚 Tafsir Entries: ${finalTafsirCount[0].count}`);
  console.log(`   📜 Hadiths: ${finalHadithCount[0].count}`);
  console.log("===========================================\n");
}
