import { eq, ilike, or, sql, and, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import {
  verses, tafsirs, hadiths,
  type Verse, type InsertVerse,
  type Tafsir, type InsertTafsir,
  type Hadith, type InsertHadith,
} from "@shared/schema";

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
});

export const db = drizzle(pool);

export interface IStorage {
  searchVerses(query: string, limit?: number): Promise<Verse[]>;
  getVersesBySurah(surahNumber: number): Promise<Verse[]>;
  getVerse(surahNumber: number, ayahNumber: number): Promise<Verse | undefined>;
  getTafsirForVerse(verseId: number): Promise<Tafsir[]>;
  getAllSurahs(): Promise<{ surahNumber: number; surahNameAr: string; surahNameEn: string; ayahCount: number }[]>;
  
  searchHadiths(query: string, limit?: number): Promise<Hadith[]>;
  getHadithsBySource(source: string, limit?: number, offset?: number): Promise<Hadith[]>;
  getHadithSources(): Promise<{ source: string; count: number }[]>;
  
  insertVerses(data: InsertVerse[]): Promise<void>;
  insertTafsirs(data: InsertTafsir[]): Promise<void>;
  insertHadiths(data: InsertHadith[]): Promise<void>;
  
  getVerseCount(): Promise<number>;
  getHadithCount(): Promise<number>;
  
  getContextForRAG(query: string, limit?: number): Promise<string>;
}

export class DatabaseStorage implements IStorage {
  async searchVerses(query: string, limit = 20): Promise<Verse[]> {
    const searchTerm = `%${query}%`;
    return db.select().from(verses)
      .where(or(
        ilike(verses.textAr, searchTerm),
        ilike(verses.textSimple, searchTerm),
        ilike(verses.surahNameAr, searchTerm),
      ))
      .limit(limit);
  }

  async getVersesBySurah(surahNumber: number): Promise<Verse[]> {
    return db.select().from(verses)
      .where(eq(verses.surahNumber, surahNumber))
      .orderBy(asc(verses.ayahNumber));
  }

  async getVerse(surahNumber: number, ayahNumber: number): Promise<Verse | undefined> {
    const result = await db.select().from(verses)
      .where(and(eq(verses.surahNumber, surahNumber), eq(verses.ayahNumber, ayahNumber)))
      .limit(1);
    return result[0];
  }

  async getTafsirForVerse(verseId: number): Promise<Tafsir[]> {
    return db.select().from(tafsirs)
      .where(eq(tafsirs.verseId, verseId));
  }

  async getAllSurahs(): Promise<{ surahNumber: number; surahNameAr: string; surahNameEn: string; ayahCount: number }[]> {
    const result = await db.select({
      surahNumber: verses.surahNumber,
      surahNameAr: verses.surahNameAr,
      surahNameEn: verses.surahNameEn,
      ayahCount: sql<number>`count(*)::int`,
    }).from(verses)
      .groupBy(verses.surahNumber, verses.surahNameAr, verses.surahNameEn)
      .orderBy(asc(verses.surahNumber));
    return result;
  }

  async searchHadiths(query: string, limit = 20): Promise<Hadith[]> {
    const searchTerm = `%${query}%`;
    return db.select().from(hadiths)
      .where(or(
        ilike(hadiths.textAr, searchTerm),
        ilike(hadiths.narrator, searchTerm),
      ))
      .limit(limit);
  }

  async getHadithsBySource(source: string, limit = 50, offset = 0): Promise<Hadith[]> {
    return db.select().from(hadiths)
      .where(eq(hadiths.source, source))
      .limit(limit)
      .offset(offset);
  }

  async getHadithSources(): Promise<{ source: string; count: number }[]> {
    const result = await db.select({
      source: hadiths.source,
      count: sql<number>`count(*)::int`,
    }).from(hadiths)
      .groupBy(hadiths.source);
    return result;
  }

  async insertVerses(data: InsertVerse[]): Promise<void> {
    if (data.length === 0) return;
    const batchSize = 500;
    for (let i = 0; i < data.length; i += batchSize) {
      const batch = data.slice(i, i + batchSize);
      await db.insert(verses).values(batch);
    }
  }

  async insertTafsirs(data: InsertTafsir[]): Promise<void> {
    if (data.length === 0) return;
    const batchSize = 500;
    for (let i = 0; i < data.length; i += batchSize) {
      const batch = data.slice(i, i + batchSize);
      await db.insert(tafsirs).values(batch);
    }
  }

  async insertHadiths(data: InsertHadith[]): Promise<void> {
    if (data.length === 0) return;
    const batchSize = 500;
    for (let i = 0; i < data.length; i += batchSize) {
      const batch = data.slice(i, i + batchSize);
      await db.insert(hadiths).values(batch);
    }
  }

  async getVerseCount(): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)::int` }).from(verses);
    return result[0]?.count || 0;
  }

  async getHadithCount(): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)::int` }).from(hadiths);
    return result[0]?.count || 0;
  }

  async getContextForRAG(query: string, limit = 5): Promise<string> {
    const searchTerm = `%${query}%`;
    
    const matchedVerses = await db.select().from(verses)
      .where(or(
        ilike(verses.textAr, searchTerm),
        ilike(verses.textSimple, searchTerm),
      ))
      .limit(limit);

    const matchedHadiths = await db.select().from(hadiths)
      .where(ilike(hadiths.textAr, searchTerm))
      .limit(limit);

    let context = "";

    if (matchedVerses.length > 0) {
      context += "=== آيات قرآنية ذات صلة ===\n";
      for (const v of matchedVerses) {
        context += `سورة ${v.surahNameAr} - الآية ${v.ayahNumber}: ${v.textAr}\n`;
        const tafsirResults = await this.getTafsirForVerse(v.id);
        if (tafsirResults.length > 0) {
          context += `التفسير: ${tafsirResults[0].textAr.substring(0, 300)}\n`;
        }
        context += "\n";
      }
    }

    if (matchedHadiths.length > 0) {
      context += "=== أحاديث نبوية ذات صلة ===\n";
      for (const h of matchedHadiths) {
        context += `${h.source} - ${h.chapter}: ${h.textAr}\n`;
        if (h.grade) context += `الحكم: ${h.grade}\n`;
        context += "\n";
      }
    }

    return context;
  }
}

export const storage = new DatabaseStorage();
