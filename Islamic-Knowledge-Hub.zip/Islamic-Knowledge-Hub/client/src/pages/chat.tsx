import { useState, useRef, useEffect } from "react";
import { Send, User, Bot, Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { api } from "@/lib/api";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
}

const QUICK_QUESTIONS = [
  "ما هو حكم صلاة الجمعة؟",
  "ما معنى آية الكرسي؟",
  "كيف أبر والدي؟",
  "ما فضل الصبر في الإسلام؟",
];

export default function ChatPage() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "أهلاً بك. أنا مساعدك الإسلامي الذكي. يمكنك سؤالي عن تفسير آية، صحة حديث، أو أي مسألة شرعية، وسأجيبك موثقاً بالأدلة من القرآن والسنة."
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSend = async (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim() || isTyping) return;

    const userMsg: Message = { id: Date.now().toString(), role: "user", content: messageText };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput("");
    setIsTyping(true);

    try {
      const chatHistory = updatedMessages
        .filter(m => m.id !== "1")
        .map(m => ({ role: m.role, content: m.content }));

      const response = await api.chat(chatHistory);

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response.content,
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error: any) {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: `عذراً، حدث خطأ: ${error.message}. يرجى المحاولة مرة أخرى.`,
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="h-[calc(100vh-2rem)] md:h-screen flex flex-col max-w-4xl mx-auto p-4 md:p-6">
      <div className="flex-1 bg-card/50 border border-border rounded-2xl overflow-hidden flex flex-col shadow-sm backdrop-blur-sm">
        
        <div className="p-4 border-b border-border bg-card flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-full text-primary">
            <Sparkles size={18} />
          </div>
          <div>
            <h2 className="font-bold text-sm">المساعد الإسلامي</h2>
            <p className="text-xs text-muted-foreground">مدعوم بـ Groq AI والمصادر الموثوقة</p>
          </div>
        </div>

        <ScrollArea className="flex-1 p-4">
          <div className="space-y-6 pb-4">
            {messages.map((msg) => (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "flex gap-4 max-w-[85%]",
                  msg.role === "user" ? "mr-auto flex-row-reverse" : ""
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-1",
                  msg.role === "user" ? "bg-accent text-white" : "bg-primary text-white"
                )}>
                  {msg.role === "user" ? <User size={14} /> : <Bot size={14} />}
                </div>
                <div className={cn(
                  "p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap",
                  msg.role === "user" 
                    ? "bg-accent/10 text-foreground rounded-tl-none" 
                    : "bg-card border border-border rounded-tr-none shadow-sm"
                )}>
                  {msg.content}
                </div>
              </motion.div>
            ))}

            {isTyping && (
              <div className="flex gap-4 max-w-[85%]">
                <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center shrink-0">
                  <Bot size={14} />
                </div>
                <div className="bg-card border border-border p-4 rounded-2xl rounded-tr-none shadow-sm flex gap-2 items-center">
                  <Loader2 size={16} className="animate-spin text-primary" />
                  <span className="text-sm text-muted-foreground">يبحث في المصادر ويكتب الرد...</span>
                </div>
              </div>
            )}

            {messages.length === 1 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-4">
                {QUICK_QUESTIONS.map((q) => (
                  <button
                    key={q}
                    data-testid={`button-quick-${q}`}
                    onClick={() => handleSend(q)}
                    className="text-sm text-right p-3 rounded-xl border border-border bg-muted/30 hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}

            <div ref={scrollRef} />
          </div>
        </ScrollArea>

        <div className="p-4 bg-card border-t border-border">
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSend(); }}
            className="flex gap-2"
          >
            <Input 
              data-testid="input-chat"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="اكتب سؤالك هنا..."
              className="flex-1"
              disabled={isTyping}
            />
            <Button type="submit" size="icon" disabled={!input.trim() || isTyping} data-testid="button-send">
              <Send size={18} />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}