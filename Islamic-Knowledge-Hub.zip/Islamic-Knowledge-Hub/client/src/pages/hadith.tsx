import { useQuery } from "@tanstack/react-query";
import { api, type HadithResult, type HadithSource } from "@/lib/api";
import { useState } from "react";
import { Book, ChevronLeft, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

export default function HadithPage() {
  const [selectedSource, setSelectedSource] = useState<string | null>(null);

  const { data: sources, isLoading: sourcesLoading } = useQuery({
    queryKey: ["hadith-sources"],
    queryFn: api.getHadithSources,
  });

  const { data: hadithsList, isLoading: hadithsLoading } = useQuery({
    queryKey: ["hadiths", selectedSource],
    queryFn: () => api.getHadithsBySource(selectedSource!),
    enabled: !!selectedSource,
  });

  if (sourcesLoading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="animate-spin text-primary" size={32} />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto">
      {!selectedSource ? (
        <div className="space-y-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-primary/10 rounded-xl text-primary">
              <Book size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold">السنة النبوية</h1>
              <p className="text-muted-foreground text-sm">تصفح كتب الحديث الشريف</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {sources?.map((src) => (
              <motion.div
                key={src.source}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                data-testid={`card-source-${src.source}`}
                onClick={() => setSelectedSource(src.source)}
                className="bg-card border border-border rounded-xl p-6 cursor-pointer hover:shadow-md hover:border-primary/20 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-foreground">{src.source}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{src.count} حديث</p>
                  </div>
                  <ChevronLeft size={20} className="text-muted-foreground" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setSelectedSource(null)} 
              className="text-primary hover:underline text-sm"
              data-testid="button-back-sources"
            >
              العودة لقائمة الكتب
            </button>
          </div>

          <div className="border-b border-border pb-4">
            <h1 className="text-2xl font-bold">{selectedSource}</h1>
            <p className="text-muted-foreground text-sm">{hadithsList?.length || 0} حديث</p>
          </div>

          {hadithsLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="animate-spin text-primary" size={32} />
            </div>
          ) : (
            <div className="space-y-4">
              {hadithsList?.map((hadith) => (
                <div 
                  key={hadith.id} 
                  data-testid={`card-hadith-detail-${hadith.id}`}
                  className="bg-card border border-border rounded-xl p-5 space-y-3"
                >
                  <div className="flex justify-between items-center text-xs text-muted-foreground">
                    <span>{hadith.chapter}</span>
                    <div className="flex items-center gap-2">
                      <span>رقم {hadith.numberInBook}</span>
                      {hadith.grade && (
                        <Badge 
                          variant={hadith.grade === "صحيح" ? "default" : "secondary"}
                          className="text-[10px] h-5"
                        >
                          {hadith.grade}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <p className="font-serif text-lg leading-relaxed">{hadith.textAr}</p>
                  {hadith.narrator && (
                    <p className="text-xs text-muted-foreground border-r-2 border-accent/30 pr-2">
                      الراوي: {hadith.narrator}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}