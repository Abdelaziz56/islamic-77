import { useLocation } from "wouter";
import { ArrowRight, BookOpen, Share2, Bookmark, MessageCircle, Search, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { api, type VerseResult, type HadithResult } from "@/lib/api";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export default function SearchPage() {
  const [_, setLocation] = useLocation();
  const urlQuery = new URLSearchParams(window.location.search).get("q") || "";
  const [searchInput, setSearchInput] = useState(urlQuery);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["search", urlQuery],
    queryFn: () => api.search(urlQuery),
    enabled: !!urlQuery,
  });

  useEffect(() => {
    setSearchInput(urlQuery);
  }, [urlQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchInput)}`);
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/")} data-testid="button-back">
          <ArrowRight />
        </Button>
        <form onSubmit={handleSearch} className="flex-1 flex gap-2">
          <div className="relative flex-1">
            <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              data-testid="input-search-page"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pr-10"
              placeholder="ابحث في القرآن والحديث..."
            />
          </div>
          <Button type="submit" data-testid="button-search">بحث</Button>
        </form>
      </div>

      {isLoading && (
        <div className="flex justify-center py-20">
          <Loader2 className="animate-spin text-primary" size={32} />
        </div>
      )}

      {!isLoading && urlQuery && data && (
        <>
          <p className="text-muted-foreground text-sm" data-testid="text-results-count">
            نتائج البحث عن "{urlQuery}" — {data.verses.length} آية و {data.hadiths.length} حديث
          </p>

          <div className="grid md:grid-cols-[2fr_1fr] gap-8">
            <div className="space-y-4">
              <h2 className="text-xl font-bold flex items-center gap-2 pb-2 border-b">
                <BookOpen size={20} className="text-primary" />
                الآيات القرآنية ({data.verses.length})
              </h2>
              
              {data.verses.length === 0 && (
                <p className="text-muted-foreground text-center py-8">لم يتم العثور على آيات مطابقة</p>
              )}

              {data.verses.map((verse) => (
                <VerseCard key={verse.id} verse={verse} query={urlQuery} />
              ))}
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-bold flex items-center gap-2 pb-2 border-b">
                <BookOpen size={20} className="text-secondary-foreground" />
                الأحاديث ({data.hadiths.length})
              </h2>

              {data.hadiths.length === 0 && (
                <p className="text-muted-foreground text-center py-8">لم يتم العثور على أحاديث مطابقة</p>
              )}

              {data.hadiths.map((hadith) => (
                <HadithCard key={hadith.id} hadith={hadith} query={urlQuery} />
              ))}
            </div>
          </div>
        </>
      )}

      {!urlQuery && (
        <div className="text-center py-20 text-muted-foreground">
          <Search size={48} className="mx-auto mb-4 opacity-30" />
          <p>اكتب كلمة للبحث في القرآن والأحاديث</p>
        </div>
      )}
    </div>
  );
}

function highlightText(text: string, query: string) {
  if (!query) return text;
  const parts = text.split(new RegExp(`(${query})`, "gi"));
  return parts.map((part, i) =>
    part.toLowerCase() === query.toLowerCase() ? (
      <mark key={i} className="bg-accent/20 text-foreground rounded px-0.5">{part}</mark>
    ) : part
  );
}

function VerseCard({ verse, query }: { verse: VerseResult; query: string }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      data-testid={`card-verse-${verse.id}`}
      className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-md transition-shadow"
    >
      <div className="bg-muted/30 px-4 py-2 flex justify-between items-center border-b border-border/50">
        <Badge variant="outline" className="bg-background text-primary border-primary/20">
          {verse.surahNameAr} : {verse.ayahNumber}
        </Badge>
      </div>
      <div className="p-6 space-y-4">
        <p className="font-quran text-2xl md:text-3xl text-center leading-loose text-foreground">
          {highlightText(verse.textAr, query)}
        </p>
        {verse.tafsir && (
          <p className="text-muted-foreground text-sm border-r-2 border-accent/50 pr-3 mr-1 leading-relaxed">
            {verse.tafsir.substring(0, 200)}...
          </p>
        )}
      </div>
    </motion.div>
  );
}

function HadithCard({ hadith, query }: { hadith: HadithResult; query: string }) {
  return (
    <div data-testid={`card-hadith-${hadith.id}`} className="bg-card border border-border rounded-xl p-4 text-sm space-y-2">
      <div className="flex justify-between items-center text-xs text-muted-foreground">
        <span>{hadith.source}</span>
        {hadith.grade && <Badge variant="secondary" className="text-[10px] h-5">{hadith.grade}</Badge>}
      </div>
      <p className="leading-relaxed font-serif text-base">
        {highlightText(hadith.textAr, query)}
      </p>
      {hadith.narrator && (
        <p className="text-xs text-muted-foreground">الراوي: {hadith.narrator}</p>
      )}
    </div>
  );
}