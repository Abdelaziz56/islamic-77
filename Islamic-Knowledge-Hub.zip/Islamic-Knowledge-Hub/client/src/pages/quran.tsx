import { useQuery } from "@tanstack/react-query";
import { api, type SurahInfo, type VerseResult } from "@/lib/api";
import { useState } from "react";
import { BookOpen, ChevronLeft, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function QuranPage() {
  const [selectedSurah, setSelectedSurah] = useState<number | null>(null);

  const { data: surahs, isLoading: surahsLoading } = useQuery({
    queryKey: ["surahs"],
    queryFn: api.getSurahs,
  });

  const { data: verses, isLoading: versesLoading } = useQuery({
    queryKey: ["surah", selectedSurah],
    queryFn: () => api.getSurah(selectedSurah!),
    enabled: !!selectedSurah,
  });

  if (surahsLoading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="animate-spin text-primary" size={32} />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto">
      {!selectedSurah ? (
        <div className="space-y-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-primary/10 rounded-xl text-primary">
              <BookOpen size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold">المصحف الشريف</h1>
              <p className="text-muted-foreground text-sm">اختر سورة للقراءة مع التفسير</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {surahs?.map((surah) => (
              <motion.div
                key={surah.surahNumber}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                data-testid={`card-surah-${surah.surahNumber}`}
                onClick={() => setSelectedSurah(surah.surahNumber)}
                className="bg-card border border-border rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:shadow-md hover:border-primary/20 transition-all"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                  {surah.surahNumber}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-foreground">{surah.surahNameAr}</h3>
                  <p className="text-xs text-muted-foreground">{surah.surahNameEn} — {surah.ayahCount} آية</p>
                </div>
                <ChevronLeft size={16} className="text-muted-foreground" />
              </motion.div>
            ))}
          </div>
        </div>
      ) : (
        <SurahView 
          surahNumber={selectedSurah} 
          verses={verses || []} 
          loading={versesLoading}
          onBack={() => setSelectedSurah(null)} 
        />
      )}
    </div>
  );
}

function SurahView({ surahNumber, verses, loading, onBack }: { 
  surahNumber: number; 
  verses: VerseResult[]; 
  loading: boolean;
  onBack: () => void;
}) {
  const [expandedTafsir, setExpandedTafsir] = useState<number | null>(null);
  const surahName = verses[0]?.surahNameAr || "";

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="text-primary hover:underline text-sm" data-testid="button-back-surahs">
          العودة للفهرس
        </button>
      </div>

      <div className="text-center py-6 border-b border-border">
        <h1 className="text-3xl font-bold font-serif text-foreground mb-2">
          سورة {surahName}
        </h1>
        <p className="text-muted-foreground text-sm">{verses.length} آية</p>
      </div>

      {loading ? (
        <div className="flex justify-center py-10">
          <Loader2 className="animate-spin text-primary" size={32} />
        </div>
      ) : (
        <div className="space-y-4">
          {surahNumber !== 1 && surahNumber !== 9 && (
            <p className="font-quran text-2xl text-center text-muted-foreground py-4">
              بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ
            </p>
          )}
          
          {verses.map((verse) => (
            <div key={verse.id} data-testid={`verse-${verse.surahNumber}-${verse.ayahNumber}`} className="bg-card border border-border rounded-xl p-5 space-y-3">
              <div className="flex justify-between items-start">
                <Badge variant="outline" className="bg-primary/5 text-primary border-primary/15 text-xs">
                  {verse.ayahNumber}
                </Badge>
              </div>
              <p className="font-quran text-2xl md:text-3xl text-center leading-loose text-foreground py-2">
                {verse.textAr}
              </p>
              {verse.tafsir && (
                <div className="border-t border-border pt-3">
                  <button
                    data-testid={`button-tafsir-${verse.id}`}
                    onClick={() => setExpandedTafsir(expandedTafsir === verse.id ? null : verse.id)}
                    className="text-sm text-primary hover:underline underline-offset-4"
                  >
                    {expandedTafsir === verse.id ? "إخفاء التفسير" : "عرض التفسير"}
                  </button>
                  {expandedTafsir === verse.id && (
                    <motion.p 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="text-sm text-muted-foreground mt-2 leading-relaxed border-r-2 border-accent/50 pr-3"
                    >
                      {verse.tafsir}
                    </motion.p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}