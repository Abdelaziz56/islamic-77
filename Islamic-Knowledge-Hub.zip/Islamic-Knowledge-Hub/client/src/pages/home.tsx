import { motion } from "framer-motion";
import { Search, Sparkles, BookOpen, Scroll } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/api";
import bgPattern from "@/assets/images/bg-pattern.png";

const SUGGESTIONS = ["الصلاة", "الصبر", "بر الوالدين", "الرحمة", "الزكاة", "الصيام", "التوحيد", "القرآن"];

export default function Home() {
  const [_, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: stats } = useQuery({
    queryKey: ["stats"],
    queryFn: api.getStats,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] md:min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none"
           style={{ backgroundImage: `url(${bgPattern})`, backgroundSize: '400px' }} />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="text-center w-full max-w-3xl z-10 space-y-8"
      >
        <div className="space-y-4">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent/10 text-accent text-sm font-medium border border-accent/20" data-testid="badge-ai">
            <Sparkles size={14} />
            <span>مدعوم بالذكاء الاصطناعي</span>
          </span>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground font-serif">
            الباحث الإسلامي الشامل
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto font-sans">
            منصة ذكية تربط علوم القرآن والسنة والتفسير، لتقدم لك إجابات دقيقة وموثقة.
          </p>
        </div>

        <form onSubmit={handleSearch} className="relative max-w-xl mx-auto w-full group">
          <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-muted-foreground group-focus-within:text-primary transition-colors">
            <Search size={22} />
          </div>
          <Input 
            data-testid="input-search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-16 pr-14 pl-6 text-lg rounded-2xl shadow-lg border-muted/40 bg-card/80 backdrop-blur-sm focus:ring-2 focus:ring-primary/20 transition-all hover:shadow-xl"
            placeholder="ابحث عن آية، حديث، أو اسأل سؤالاً فقهياً..." 
          />
        </form>

        <div className="flex flex-wrap justify-center gap-2 text-sm text-muted-foreground">
          <span>جرب البحث عن:</span>
          {SUGGESTIONS.slice(0, 5).map((s) => (
            <button 
              key={s}
              data-testid={`link-suggestion-${s}`}
              onClick={() => setLocation(`/search?q=${s}`)}
              className="text-primary hover:underline underline-offset-4 font-medium"
            >
              {s}
            </button>
          ))}
        </div>

        {stats && (
          <div className="flex justify-center gap-8 text-sm text-muted-foreground pt-2">
            <span data-testid="text-verse-count">{stats.verseCount} آية</span>
            <span>|</span>
            <span data-testid="text-hadith-count">{stats.hadithCount} حديث</span>
            <span>|</span>
            <span data-testid="text-surah-count">{stats.surahCount} سورة</span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-8">
          <FeatureCard 
            icon={BookOpen} 
            title="القرآن الكريم" 
            desc="بحث دلالي في الآيات مع ربطها بالتفاسير المعتمدة."
            href="/quran"
          />
          <FeatureCard 
            icon={Scroll} 
            title="الحديث الشريف" 
            desc="تخريج الأحاديث والحكم على صحتها من المصادر."
            href="/hadith"
          />
          <FeatureCard 
            icon={Sparkles} 
            title="المساعد الذكي" 
            desc="إجابات فورية مدعمة بالأدلة من الكتاب والسنة."
            href="/chat"
          />
        </div>
      </motion.div>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc, href }: { icon: any, title: string, desc: string, href: string }) {
  const [_, setLocation] = useLocation();
  return (
    <div 
      data-testid={`card-feature-${title}`}
      onClick={() => setLocation(href)}
      className="p-6 rounded-2xl bg-card/50 border border-border/50 hover:bg-card hover:shadow-md transition-all text-right cursor-pointer"
    >
      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-4">
        <Icon size={24} />
      </div>
      <h3 className="text-lg font-bold mb-2 font-sans">{title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}