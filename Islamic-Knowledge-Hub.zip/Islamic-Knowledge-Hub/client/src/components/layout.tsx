import { Link, useLocation } from "wouter";
import { BookOpen, Search, MessageSquare, Menu, Settings, Moon, Sun, Home, Book } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

// Simple theme hook
function useDarkMode() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const isDarkStored = localStorage.getItem("theme") === "dark";
    setIsDark(isDarkStored);
    if (isDarkStored) {
      document.documentElement.classList.add("dark");
    }
  }, []);

  const toggle = () => {
    const newDark = !isDark;
    setIsDark(newDark);
    if (newDark) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  };

  return { isDark, toggle };
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { isDark, toggle } = useDarkMode();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { icon: Home, label: "الرئيسية", href: "/" },
    { icon: Search, label: "الباحث الذكي", href: "/search" },
    { icon: BookOpen, label: "المصحف الشريف", href: "/quran" },
    { icon: Book, label: "السنة النبوية", href: "/hadith" },
    { icon: MessageSquare, label: "المساعد الذكي", href: "/chat" },
  ];

  const NavContent = () => (
    <div className="flex flex-col h-full py-6">
      <div className="px-6 mb-8 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold">
          ب
        </div>
        <h1 className="text-xl font-bold tracking-tight">البيــان</h1>
      </div>
      
      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 cursor-pointer",
                location === item.href 
                  ? "bg-primary/10 text-primary font-medium" 
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </div>
          </Link>
        ))}
      </nav>

      <div className="px-6 mt-auto">
        <div className="p-4 rounded-xl bg-muted/50 border border-border">
          <p className="text-xs text-muted-foreground mb-3">نمط العرض</p>
          <div className="flex items-center gap-2 bg-background p-1 rounded-lg border border-input">
            <button 
              onClick={() => isDark && toggle()}
              className={cn("flex-1 p-1.5 rounded-md flex items-center justify-center transition-all", !isDark && "bg-white shadow-sm text-primary")}
            >
              <Sun size={16} />
            </button>
            <button 
              onClick={() => !isDark && toggle()}
              className={cn("flex-1 p-1.5 rounded-md flex items-center justify-center transition-all", isDark && "bg-slate-800 shadow-sm text-primary")}
            >
              <Moon size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-72 border-l border-border h-screen sticky top-0 bg-card/50 backdrop-blur-xl">
        <NavContent />
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header */}
        <header className="md:hidden h-16 border-b border-border flex items-center justify-between px-4 bg-card">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold">
              ب
            </div>
            <span className="font-bold">البيان</span>
          </div>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="p-0 border-l border-border">
              <NavContent />
            </SheetContent>
          </Sheet>
        </header>

        <div className="flex-1 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
}