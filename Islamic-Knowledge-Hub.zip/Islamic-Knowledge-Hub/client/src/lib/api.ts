import { queryClient } from "./queryClient";

const API_BASE = "/api";

async function fetchApi<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: "خطأ في الاتصال" }));
    throw new Error(err.message || "حدث خطأ");
  }
  return res.json();
}

export interface VerseResult {
  id: number;
  surahNumber: number;
  surahNameAr: string;
  surahNameEn: string;
  ayahNumber: number;
  textAr: string;
  textSimple: string;
  juzNumber: number;
  tafsir?: string;
}

export interface HadithResult {
  id: number;
  source: string;
  chapter: string;
  numberInBook: number;
  textAr: string;
  grade: string;
  narrator: string;
}

export interface SearchResult {
  verses: VerseResult[];
  hadiths: HadithResult[];
}

export interface SurahInfo {
  surahNumber: number;
  surahNameAr: string;
  surahNameEn: string;
  ayahCount: number;
}

export interface HadithSource {
  source: string;
  count: number;
}

export interface Stats {
  verseCount: number;
  hadithCount: number;
  surahCount: number;
}

export interface ChatResponse {
  role: "assistant";
  content: string;
  sources: string;
}

export const api = {
  search: (query: string, type = "all") =>
    fetchApi<SearchResult>(`/search?q=${encodeURIComponent(query)}&type=${type}`),

  getSurahs: () => fetchApi<SurahInfo[]>("/surahs"),

  getSurah: (num: number) => fetchApi<VerseResult[]>(`/surah/${num}`),

  getHadithSources: () => fetchApi<HadithSource[]>("/hadith/sources"),

  getHadithsBySource: (source: string, limit = 50, offset = 0) =>
    fetchApi<HadithResult[]>(`/hadith/${encodeURIComponent(source)}?limit=${limit}&offset=${offset}`),

  getStats: () => fetchApi<Stats>("/stats"),

  chat: (messages: { role: string; content: string }[]) =>
    fetchApi<ChatResponse>("/chat", {
      method: "POST",
      body: JSON.stringify({ messages }),
    }),
};
