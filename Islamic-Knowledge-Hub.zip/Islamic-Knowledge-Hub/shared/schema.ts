import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, serial, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const verses = pgTable("verses", {
  id: serial("id").primaryKey(),
  surahNumber: integer("surah_number").notNull(),
  surahNameAr: text("surah_name_ar").notNull(),
  surahNameEn: text("surah_name_en").notNull(),
  ayahNumber: integer("ayah_number").notNull(),
  textAr: text("text_ar").notNull(),
  textSimple: text("text_simple").notNull(),
  juzNumber: integer("juz_number").notNull().default(1),
}, (table) => [
  index("verses_surah_idx").on(table.surahNumber),
]);

export const tafsirs = pgTable("tafsirs", {
  id: serial("id").primaryKey(),
  verseId: integer("verse_id").notNull(),
  surahNumber: integer("surah_number").notNull(),
  ayahNumber: integer("ayah_number").notNull(),
  source: text("source").notNull().default("ابن كثير"),
  textAr: text("text_ar").notNull(),
}, (table) => [
  index("tafsirs_verse_idx").on(table.verseId),
]);

export const hadiths = pgTable("hadiths", {
  id: serial("id").primaryKey(),
  source: text("source").notNull(),
  chapter: text("chapter").notNull(),
  numberInBook: integer("number_in_book").notNull(),
  textAr: text("text_ar").notNull(),
  grade: text("grade").notNull().default(""),
  narrator: text("narrator").notNull().default(""),
}, (table) => [
  index("hadiths_source_idx").on(table.source),
]);

export const insertVerseSchema = createInsertSchema(verses).omit({ id: true });
export const insertTafsirSchema = createInsertSchema(tafsirs).omit({ id: true });
export const insertHadithSchema = createInsertSchema(hadiths).omit({ id: true });

export type InsertVerse = z.infer<typeof insertVerseSchema>;
export type Verse = typeof verses.$inferSelect;
export type InsertTafsir = z.infer<typeof insertTafsirSchema>;
export type Tafsir = typeof tafsirs.$inferSelect;
export type InsertHadith = z.infer<typeof insertHadithSchema>;
export type Hadith = typeof hadiths.$inferSelect;

export const chatMessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string(),
});
export type ChatMessage = z.infer<typeof chatMessageSchema>;
